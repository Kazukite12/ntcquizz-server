const { createUser, findUserByUsername, findUserById,findUserByEmail } = require('./user.service');
const { generateToken } = require('../../utils/jwt.util');
const bcrypt = require('bcrypt');

const {generateOtp} = require('../../utils/otpGenerator');

const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL, // Your email address
    pass: process.env.PASSWORD, // Your email password or app password
  },
});

const sendOtpEmail = async (email, otp) => {
  const mailOptions = {
    from: process.env.EMAIL,
    to: email,
    subject: 'Kode OTP Pendafataran Akun NtcQuizz',
    text: `Kode OTP Pendafataran Akun NtcQuizz Anda Adalah ${otp}. Kode OTP Berlaku Selama 5 Menit.`,
  };

  await transporter.sendMail(mailOptions);
};

const otpStore = new Map(); // Temporary storage for OTPs (use Redis or DB in production)

module.exports = {
  
  register: async (req, res) => {
    const { username, email, password } = req.body;

    // Validate input
    if (!username || !email || !password) {
      return res.status(400).json({ message: 'Username, email, and password are required.' });
    }

    try {
      // Check if username is already taken
      const existingUserByUsername = await new Promise((resolve, reject) => {
        findUserByUsername(username, (err, user) => (err ? reject(err) : resolve(user)));
      });

      if (existingUserByUsername) {
        return res.status(403).json({ message: 'Username has already been taken.' });
      }

      // Check if email is already registered
      const existingUserByEmail = await new Promise((resolve, reject) => {
        findUserByEmail(email, (err, user) => (err ? reject(err) : resolve(user)));
      });

      if (existingUserByEmail) {
        return res.status(403).json({ message: 'Email has been registered.' });
      }

      // Generate and send OTP
      const otp = generateOtp();
      otpStore.set(email, { otp, expiresAt: Date.now() + 5 * 60 * 1000 }); // TTL: 5 minutes

      await sendOtpEmail(email, otp);

      return res.status(200).json({ message: 'OTP sent to your email.' });
    } catch (error) {
      return res.status(500).json({ message: 'An error occurred.', error });
    }
  },

  verifyOtp: (req, res) => {
    const { email, otp } = req.body;

    if (!email || !otp) {
      return res.status(400).json({ message: 'Email and OTP are required.' });
    }

    const storedOtp = otpStore.get(email);
    if (!storedOtp || storedOtp.otp !== otp) {
      return res.status(400).json({ message: 'Invalid or expired OTP.' });
    }

    if (storedOtp.expiresAt < Date.now()) {
      otpStore.delete(email);
      return res.status(400).json({ message: 'OTP has expired.' });
    }

    otpStore.delete(email); // OTP verified, remove from storage
    
    // Proceed with user creation
    const { username, password } = req.body;
    createUser({ username, email, password }, (err, result) => {
      if (err) {
        return res.status(500).json({ message: 'Database error', error: err });
      }
      res.status(201).json({ message: 'User registered successfully', userId: result.insertId });
    });
  },

  login: (req, res) => {
    const { username, password } = req.body;
    // Validate input
    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required.' });
    }

    findUserByUsername(username, async (err, user) => {
      if (err) {
        return res.status(500).json({ message: 'Database error', error: err });
      }
      if (!user) {
        return res.status(404).json({ message: 'User not found.' });
      }

      // Verify password
      const isPasswordValid = await bcrypt.compare(password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ message: 'Invalid credentials.' });
      }

      const token = generateToken({ id: user.id, username: user.username });
      res.status(200).json({ message: 'Login successful', token });
    });
  },

  getProfile: (req, res) => {
    const userId = req.user.id;

    findUserById(userId, (err, user) => {
      if (err) {
        return res.status(500).json({ message: 'Database error', error: err });
      }
      if (!user) {
        return res.status(404).json({ message: 'User not found.' });
      }

      res.status(200).json({ user });
    });
  },
};
